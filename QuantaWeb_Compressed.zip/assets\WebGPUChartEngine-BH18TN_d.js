import{W as dt,r as j,j as Ce}from"./vendor-react-RtAl1mHH.js";import{c as pt,a as gt,I as mt}from"./WebContainer-DLuE-P7q.js";import"./vendor-core-DGlKcvj2.js";import"./index-DT5o_RTH.js";import"./vendor-icons-DLPYUNUd.js";import"./vendor-charts-CCdQvjV5.js";import"./exchanges-Df4GuvII.js";import"./vendor-recharts-DpnGRxRv.js";function ht(q,T,i){const te=(i.x-T.x)**2+(i.y-T.y)**2;if(te===0)return(q.x-T.x)**2+(q.y-T.y)**2;let $=((q.x-T.x)*(i.x-T.x)+(q.y-T.y)*(i.y-T.y))/te;$=Math.max(0,Math.min(1,$));const se={x:T.x+$*(i.x-T.x),y:T.y+$*(i.y-T.y)};return(q.x-se.x)**2+(q.y-se.y)**2}function xt(q,T,i){return Math.sqrt(ht(q,T,i))}function Ke(q,T,i=2){const te=T.x-q.x,$=T.y-q.y,se=Math.sqrt(te*te+$*$);if(se===0)return[];const X=-$/se*(i/2),H=te/se*(i/2),k={x:q.x+X,y:q.y+H},be={x:q.x-X,y:q.y-H},ye={x:T.x-X,y:T.y-H},K={x:T.x+X,y:T.y+H};return[k,be,ye,ye,K,k]}function vt(q,T,i,te,$,se=5){const X={x:T,y:i};for(let H=q.length-1;H>=0;H--){const k=q[H];if(k.tool==="trendline"&&k.points.length>=2){const be={x:te(k.points[0].time),y:$(k.points[0].price)},ye={x:te(k.points[1].time),y:$(k.points[1].price)};if(xt(X,be,ye)<=se)return k}}return null}function yt(q="'Inter', -apple-system, sans-serif",T=48,i=8){const te="0123456789.:- ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",se=document.createElement("canvas");se.width=512,se.height=512;const X=se.getContext("2d");if(!X)throw new Error("Could not create 2D context for SDF generation");X.fillStyle="#000000",X.fillRect(0,0,512,512),X.fillStyle="#ffffff",X.font=`bold ${T}px ${q}`,X.textBaseline="top",X.textAlign="left";const H={};let k=i,be=i;for(let ue=0;ue<te.length;ue++){const _=te[ue],He=X.measureText(_),_e=Math.ceil(He.width),Be=T,Se=_e+i*2,we=Be+i*2;k+Se>512&&(k=i,be+=we),X.fillText(_,k+i,be+i),H[_]={x:k,y:be,w:Se,h:we,cellW:Se,cellH:we},k+=Se}const K=X.getImageData(0,0,512,512).data,Ee=new Uint8Array(512*512),O=i;for(let ue=0;ue<512;ue++)for(let _=0;_<512;_++){const He=(ue*512+_)*4,_e=K[He]>127;let Be=O*O;const Se=Math.max(0,_-O),we=Math.min(511,_+O),ke=Math.max(0,ue-O),ot=Math.min(511,ue+O);for(let qe=ke;qe<=ot;qe++)for(let Ie=Se;Ie<=we;Ie++){const Ve=(qe*512+Ie)*4;if(K[Ve]>127!==_e){const pe=_-Ie,ge=ue-qe,Te=pe*pe+ge*ge;Te<Be&&(Be=Te)}}const at=Math.sqrt(Be),Ze=Math.max(0,Math.min(1,at/O));let je=128;_e?je=128+Math.floor(Ze*127):je=128-Math.floor(Ze*128),Ee[ue*512+_]=je}return{sdfData:Ee,charMap:H,atlasSize:512}}const wt=`
struct Candle {
  prices: vec4<f32>, // open, high, low, close
  metaData: vec4<f32>,   // x = timeIndex
};

struct Uniforms {
  period: f32,
  candleCount: f32,
  _pad1: f32,
  _pad2: f32,
};

@group(0) @binding(0) var<storage, read> candles: array<Candle>;
@group(0) @binding(1) var<storage, read_write> outBuffer: array<f32>;
@group(0) @binding(2) var<uniform> u: Uniforms;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
    let i = global_id.x;
    let totalCandles = u32(u.candleCount);
    let period = u32(u.period);
    
    if (i >= totalCandles) { return; }
    
    if (i < period - 1u) {
        outBuffer[i] = -1.0; // Not enough data
        return;
    }
    
    var sum = 0.0;
    for (var j = 0u; j < period; j++) {
        sum += candles[i - j].prices.w; // sum of closes
    }
    outBuffer[i] = sum / f32(period);
}
`,Pt=`
struct Uniforms {
  scale: vec2<f32>,
  offset: vec2<f32>,
  resolution: vec2<f32>,
  priceRange: vec2<f32>,
};
@group(0) @binding(0) var<uniform> u: Uniforms;
@group(0) @binding(1) var<storage, read> indicatorData: array<f32>;

struct VertexOutput {
  @builtin(position) position: vec4<f32>,
  @location(0) color: vec4<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vIdx: u32, @builtin(instance_index) iIdx: u32) -> VertexOutput {
  var out: VertexOutput;
  let val1 = indicatorData[iIdx];
  let val2 = indicatorData[iIdx + 1u];
  
  if (val1 < 0.0 || val2 < 0.0) {
     out.position = vec4<f32>(0.0, 0.0, 0.0, 0.0); // Hidden
     return out;
  }
  
  // A simple thick line using 6 vertices for a quad connecting P1 and P2
  let spacing = 10.0 * u.scale.x;
  let candleWidth = max(1.0, spacing * 0.8);
  
  let p1x = (f32(iIdx) * 10.0 * u.scale.x) + u.offset.x + (candleWidth * 0.5);
  let p2x = (f32(iIdx + 1u) * 10.0 * u.scale.x) + u.offset.x + (candleWidth * 0.5);
  
  let p1y = (u.priceRange.y - val1) * u.scale.y + u.offset.y;
  let p2y = (u.priceRange.y - val2) * u.scale.y + u.offset.y;
  
  // Calculate perpendicular vector for line thickness
  let dir = normalize(vec2<f32>(p2x - p1x, p2y - p1y));
  let normal = vec2<f32>(-dir.y, dir.x);
  let thickness = 2.0;
  
  var pos = vec2<f32>(0.0, 0.0);
  let localIdx = vIdx % 6u;
  if (localIdx == 0u) { pos = vec2<f32>(p1x, p1y) + normal * thickness; }
  if (localIdx == 1u) { pos = vec2<f32>(p2x, p2y) + normal * thickness; }
  if (localIdx == 2u) { pos = vec2<f32>(p1x, p1y) - normal * thickness; }
  if (localIdx == 3u) { pos = vec2<f32>(p1x, p1y) - normal * thickness; }
  if (localIdx == 4u) { pos = vec2<f32>(p2x, p2y) + normal * thickness; }
  if (localIdx == 5u) { pos = vec2<f32>(p2x, p2y) - normal * thickness; }
  
  // --- MANUAL PIXEL SNAPPING ---
  let snappedX = round(pos.x) + 0.5;
  let snappedY = round(pos.y) + 0.5;
  
  let clipX = (snappedX / u.resolution.x) * 2.0 - 1.0;
  let clipY = 1.0 - (snappedY / u.resolution.y) * 2.0;
  
  out.position = vec4<f32>(clipX, clipY, 0.0, 1.0);
  out.color = vec4<f32>(0.16, 0.50, 0.96, 1.0); // Blue SMA line
  return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
  return in.color;
}
`,Mt=`
struct Uniforms {
  scale: vec2<f32>,
  offset: vec2<f32>,
  resolution: vec2<f32>,
  priceRange: vec2<f32>,
};
@group(0) @binding(0) var<uniform> u: Uniforms;

struct Candle {
  prices: vec4<f32>, // open, high, low, close
  metaData: vec4<f32>,   // x = timeIndex
};
@group(0) @binding(1) var<storage, read> candles: array<Candle>;

struct VertexOutput {
  @builtin(position) position: vec4<f32>,
  @location(0) color: vec4<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vIdx: u32, @builtin(instance_index) iIdx: u32) -> VertexOutput {
  var out: VertexOutput;
  let c = candles[iIdx];
  let open = c.prices.x;
  let high = c.prices.y;
  let low = c.prices.z;
  let close = c.prices.w;
  let index = c.metaData.x;
  let isPrediction = c.metaData.y == 1.0;

  let isUp = close >= open;
  var color = select(vec4<f32>(0.949, 0.212, 0.271, 1.0), vec4<f32>(0.031, 0.600, 0.505, 1.0), isUp);
  if (isPrediction) {
    color = vec4<f32>(color.r, color.g, color.b, 0.45);
  }

  let isWick = vIdx > 5u;
  let localVIdx = vIdx % 6u;
  var quad = array<vec2<f32>, 6>(
    vec2<f32>(0.0, 0.0), vec2<f32>(1.0, 0.0), vec2<f32>(0.0, 1.0),
    vec2<f32>(0.0, 1.0), vec2<f32>(1.0, 0.0), vec2<f32>(1.0, 1.0)
  );
  let q = quad[localVIdx];

  let spacing = 10.0 * u.scale.x;
  let candleWidth = max(1.0, floor(spacing * 0.8));
  let wickWidth = max(1.0, floor(min(2.0, spacing * 0.1)));

  var topP = max(open, close);
  var botP = min(open, close);
  if (isWick) {
    topP = high;
    botP = low;
  }

  let pixelYTop = floor((u.priceRange.y - topP) * u.scale.y + u.offset.y);
  var pixelYBot = floor((u.priceRange.y - botP) * u.scale.y + u.offset.y);
  if (!isWick && (pixelYBot - pixelYTop < 1.0)) {
      pixelYBot = pixelYTop + 1.0;
  }
  
  let heightPx = max(1.0, pixelYBot - pixelYTop);
  let widthPx = select(candleWidth, wickWidth, isWick);
  let xOffset = select(0.0, floor((candleWidth - wickWidth) * 0.5), isWick);

  let pixelX = floor((index * 10.0 * u.scale.x) + u.offset.x) + xOffset;
  let pixelY = pixelYTop;

  let px = pixelX + (q.x * widthPx);
  let py = pixelY + (q.y * heightPx);

  // --- MANUAL PIXEL SNAPPING ---
  let snappedPx = round(px) + 0.5;
  let snappedPy = round(py) + 0.5;

  let clipX = (snappedPx / u.resolution.x) * 2.0 - 1.0;
  let clipY = 1.0 - (snappedPy / u.resolution.y) * 2.0;

  out.position = vec4<f32>(clipX, clipY, 0.0, 1.0);
  out.color = color;
  return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
  return in.color;
}
`,Rt=`
struct TextUniforms {
  resolution: vec2<f32>,
  textColor: vec4<f32>,  // dark/light mode color passed from CPU
};
@group(0) @binding(0) var<uniform> uniforms: TextUniforms;
@group(0) @binding(1) var fontSampler: sampler;
@group(0) @binding(2) var fontTexture: texture_2d<f32>;

struct Character {
  posInfo: vec4<f32>, // x, y, pad, pad
  uvInfo: vec4<f32>,  // ux, uy, uw, uh (in atlas pixels)
};
@group(0) @binding(3) var<storage, read> chars: array<Character>;

struct VertexOutput {
  @builtin(position) position: vec4<f32>,
  @location(0) uv: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vIdx: u32, @builtin(instance_index) iIdx: u32) -> VertexOutput {
  var out: VertexOutput;
  let charData = chars[iIdx];
  
  var quad = array<vec2<f32>, 6>(
    vec2<f32>(0.0, 0.0), vec2<f32>(1.0, 0.0), vec2<f32>(0.0, 1.0),
    vec2<f32>(0.0, 1.0), vec2<f32>(1.0, 0.0), vec2<f32>(1.0, 1.0)
  );
  let q = quad[vIdx % 6u];
  
  let w = charData.uvInfo.z;
  let h = charData.uvInfo.w;
  // Pixel-snap the glyph quad position for crisp rendering (same as Canvas 2D)
  let px = floor(charData.posInfo.x) + (q.x * w);
  let py = floor(charData.posInfo.y) + (q.y * h);
  
  let clipX = (px / uniforms.resolution.x) * 2.0 - 1.0;
  let clipY = 1.0 - (py / uniforms.resolution.y) * 2.0;
  out.position = vec4<f32>(clipX, clipY, 0.0, 1.0);
  
  let atlasSize = 512.0;
  out.uv = vec2<f32>(
    (charData.uvInfo.x + q.x * w) / atlasSize,
    (charData.uvInfo.y + q.y * h) / atlasSize
  );
  return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
  let distance = textureSample(fontTexture, fontSampler, in.uv).r;
  // Crisp smoothstep threshold — identical look to Canvas 2D fillText
  let crispAlpha = smoothstep(0.40, 0.55, distance);
  if (crispAlpha < 0.01) { discard; }
  return vec4<f32>(uniforms.textColor.rgb, uniforms.textColor.a * crispAlpha);
}
`,St=`
struct Uniforms {
  resolution: vec2<f32>,
  hoverPixel: vec2<f32>,
  gridSpacing: vec2<f32>,
  offset: vec2<f32>,
  axisSize: vec2<f32>,
  livePixelY: f32,
  lastPixelX: f32,
  liveColor: vec4<f32>,
};
@group(0) @binding(0) var<uniform> uniforms: Uniforms;

struct VertexOutput {
  @builtin(position) position: vec4<f32>,
  @location(0) fragPos: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) VertexIndex: u32) -> VertexOutput {
  var pos = array<vec2<f32>, 6>(
    vec2<f32>(-1.0, -1.0), vec2<f32>( 1.0, -1.0), vec2<f32>(-1.0,  1.0),
    vec2<f32>(-1.0,  1.0), vec2<f32>( 1.0, -1.0), vec2<f32>( 1.0,  1.0)
  );
  var out: VertexOutput;
  out.position = vec4<f32>(pos[VertexIndex], 0.0, 1.0);
  out.fragPos = vec2<f32>(
    (pos[VertexIndex].x + 1.0) * 0.5 * uniforms.resolution.x,
    (1.0 - pos[VertexIndex].y) * 0.5 * uniforms.resolution.y
  );
  return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
  let coord = in.fragPos;
  
  // ── L-SHAPED AXIS BACKGROUND ──
  if (coord.x > (uniforms.resolution.x - uniforms.axisSize.x) || 
      coord.y > (uniforms.resolution.y - uniforms.axisSize.y)) {
    return vec4<f32>(0.051, 0.067, 0.090, 1.0); // Solid #0d1117 background
  }

  var finalColor = vec4<f32>(0.0, 0.0, 0.0, 0.0); // Transparent chart background
  
  // ── LIVE PRICE DASHED LINE ──
  if (uniforms.livePixelY > 0.0 && coord.x < (uniforms.resolution.x - uniforms.axisSize.x)) {
    let distY = abs(coord.y - uniforms.livePixelY);
    if (distY < 1.0) {
       // Dashed pattern: 4px dash, 4px gap
       if (u32(coord.x) % 8u < 4u) {
         finalColor = vec4<f32>(uniforms.liveColor.rgb, 0.8);
       }
    }
  }

  return finalColor;
}
`,Gt=dt.forwardRef((q,T)=>{const{candles:i=[],predictedCandle:te=null,darkMode:$=!0,chartStyle:se="candles",priceScaleMode:X=0,autoScale:H=!0,invertScale:k=!1,timezoneOffset:be=0,initialVisibleRange:ye,onVisibleRangeChange:K,onChartReady:Ee,activeTool:O=null,isHoveringDrawing:ue,drawings:_=[],tempShape:He=null,drawStart:_e=null,onDrawingComplete:Be,onDrawingDelete:Se,visualIndicators:we=[],indicatorDataMap:ke={},volumeProfile:ot=[],hoverCoords:at,selectedDrawingId:Ze,hideDrawings:je=!1,cursorSettings:qe={},onRequestDraw:Ie,onFallback:Ve}=q,Oe=j.useRef(null),pe=j.useRef(null),ge=j.useRef(null),[Te,Qe]=j.useState(null),[lt,ut]=j.useState("Detecting GPU..."),r=j.useRef({device:null,context:null,format:null,pipeline:null,uniformBuffer:null,vertexBuffer:null,vertexCount:0,minUniformAlignment:256}),n=j.useRef({logicalRange:{from:0,to:100},priceRange:{min:0,max:100},manualPriceScale:!1,width:800,height:600,isDragging:!1,dragStart:null,hoverPixel:null}),x=window.devicePixelRatio||1,Ue=(a,w)=>{if(!w||w.length===0)return 0;let P=0,D=w.length-1;for(;P<=D;){const c=P+D>>1;if(w[c].time===a)return c;w[c].time<a?P=c+1:D=c-1}return P},ct=j.useRef(null);j.useEffect(()=>{if(!i||i.length===0)return;const a=i[i.length-1].time,w=ct.current;if(w&&a>w){const P=Ue(w,i);if(n.current.logicalRange.to>=P-.5){const c=i.length-1-P;n.current.logicalRange.from+=c,n.current.logicalRange.to+=c,K&&K({from:i[Math.max(0,Math.floor(n.current.logicalRange.from))]?.time,to:i[Math.min(i.length-1,Math.ceil(n.current.logicalRange.to))]?.time})}}ct.current=a,requestAnimationFrame(ie)},[_,O,we,ke,i,K]);const Je=j.useRef(!1);j.useEffect(()=>{if(!(Je.current||!i||i.length===0)){if(Je.current=!0,ye?.visibleRange){const a=Ue(ye.visibleRange.from,i),w=Ue(ye.visibleRange.to,i);n.current.logicalRange={from:a,to:w}}else n.current.logicalRange={from:Math.max(0,i.length-80),to:i.length-1+20};ge.current=requestAnimationFrame(ie)}},[ye,i]),j.useEffect(()=>{let a=!0;async function w(){if(!navigator.gpu){Qe("WebGPU not supported on this browser/OS.");return}try{let P=await navigator.gpu.requestAdapter({powerPreference:"high-performance"});if(P||(P=await navigator.gpu.requestAdapter()),P||(P=await navigator.gpu.requestAdapter({powerPreference:"low-power"})),!P)throw new Error("WebGPU Adapter initialization failed. No adapter found.");let D="NVIDIA / HIGH-PERFORMANCE DISCRETE GPU";try{let h=!1;try{const o=document.createElement("canvas"),g=o.getContext("webgl2",{powerPreference:"high-performance"})||o.getContext("webgl",{powerPreference:"high-performance"});if(g){const s=g.getExtension("WEBGL_debug_renderer_info");if(s){const S=g.getParameter(s.UNMASKED_RENDERER_WEBGL);S&&(S.toLowerCase().includes("nvidia")||S.toLowerCase().includes("geforce")||S.toLowerCase().includes("rtx")||S.toLowerCase().includes("gtx"))&&(D=`NVIDIA (${S.replace(/^ANGLE \(([^,]+),\s*/,"").replace(/\s*Direct3D.*$/,"")})`,h=!0)}}}catch{}if(!h){let o="Discrete GPU",g="Hardware Accelerated";if("info"in P&&P.info){const s=P.info;o=s.vendor||s.architecture||"Discrete GPU",g=s.architecture||s.device||s.description||"Native WGSL Pipeline"}else if("requestAdapterInfo"in P){const s=await P.requestAdapterInfo();o=s.vendor||s.architecture||"Discrete GPU",g=s.architecture||s.device||s.description||"Native WGSL Pipeline"}D=`${o.toUpperCase()} (${g})`}}catch{}ut(D);let c;try{c=await P.requestDevice()}catch(h){throw h}if(!a){c.destroy();return}r.current.device=c,r.current.minUniformAlignment=c.limits?.minUniformBufferOffsetAlignment||256,c.lost.then(h=>{Je.current=!1,r.current.deviceLost=!0,Qe("WebGPU device lost. Re-initializing hardware engine..."),setTimeout(()=>{a&&w()},1e3)});const V=pe.current.getContext("webgpu");r.current.context=V;const W=navigator.gpu.getPreferredCanvasFormat();r.current.format=W,V.configure({device:c,format:W,alphaMode:"opaque"});const N=c.createBuffer({size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});r.current.uniformBuffer=N;const ne=1e5,F=c.createBuffer({size:ne*32,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});r.current.candleBuffer=F,r.current.maxCandles=ne;const Z=c.createShaderModule({code:Mt}),me=c.createRenderPipeline({layout:"auto",vertex:{module:Z,entryPoint:"vs_main"},fragment:{module:Z,entryPoint:"fs_main",targets:[{format:W}]},primitive:{topology:"triangle-list"}});r.current.pipeline=me,r.current.bindGroup=c.createBindGroup({layout:me.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:N}},{binding:1,resource:{buffer:F}}]});const he=c.createBuffer({size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});r.current.computeUniformBuffer=he;const B=c.createBuffer({size:ne*4,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC});r.current.indicatorBuffer=B;const oe=c.createShaderModule({code:wt}),Q=c.createComputePipeline({layout:"auto",compute:{module:oe,entryPoint:"main"}});r.current.computePipeline=Q,r.current.computeBindGroup=c.createBindGroup({layout:Q.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:F}},{binding:1,resource:{buffer:B}},{binding:2,resource:{buffer:he}}]});const fe=c.createShaderModule({code:Pt}),J=c.createRenderPipeline({layout:"auto",vertex:{module:fe,entryPoint:"vs_main"},fragment:{module:fe,entryPoint:"fs_main",targets:[{format:W,blend:{color:{srcFactor:"src-alpha",dstFactor:"one-minus-src-alpha",operation:"add"},alpha:{srcFactor:"one",dstFactor:"one-minus-src-alpha",operation:"add"}}}]},primitive:{topology:"triangle-list"}});r.current.linePipeline=J,r.current.lineBindGroup=c.createBindGroup({layout:J.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:N}},{binding:1,resource:{buffer:B}}]});const ae=c.createBuffer({size:64,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});r.current.gridUniformBuffer=ae;const xe=c.createShaderModule({code:St});r.current.gridPipeline=c.createRenderPipeline({layout:"auto",vertex:{module:xe,entryPoint:"vs_main"},fragment:{module:xe,entryPoint:"fs_main",targets:[{format:W,blend:{color:{srcFactor:"src-alpha",dstFactor:"one-minus-src-alpha",operation:"add"},alpha:{srcFactor:"one",dstFactor:"one-minus-src-alpha",operation:"add"}}}]},primitive:{topology:"triangle-list"}}),r.current.gridBindGroup=c.createBindGroup({layout:r.current.gridPipeline.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:ae}}]});const{sdfData:y,charMap:I,atlasSize:E}=yt("'Inter', -apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, sans-serif",Math.floor(12*x),8);r.current.charMap=I;const t=c.createTexture({size:[E,E,1],format:"r8unorm",usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST});c.queue.writeTexture({texture:t},y,{bytesPerRow:E,rowsPerImage:E},[E,E,1]);const e=c.createSampler({magFilter:"linear",minFilter:"linear",addressModeU:"clamp-to-edge",addressModeV:"clamp-to-edge"}),d=c.createBuffer({size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});r.current.textUniformBuffer=d;const M=2e3,p=c.createBuffer({size:M*32,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});r.current.textStorageBuffer=p,r.current.maxChars=M;const m=c.createShaderModule({code:Rt}),u=c.createRenderPipeline({layout:"auto",vertex:{module:m,entryPoint:"vs_main"},fragment:{module:m,entryPoint:"fs_main",targets:[{format:W,blend:{color:{srcFactor:"src-alpha",dstFactor:"one-minus-src-alpha",operation:"add"},alpha:{srcFactor:"one",dstFactor:"one-minus-src-alpha",operation:"add"}}}]},primitive:{topology:"triangle-list"}});r.current.textPipeline=u,r.current.textBindGroup=c.createBindGroup({layout:u.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:d}},{binding:1,resource:e},{binding:2,resource:t.createView()},{binding:3,resource:{buffer:p}}]});const U=c.createShaderModule({code:`
          struct Uniforms { cw: f32, ch: f32, pad1: f32, pad2: f32 };
          @group(0) @binding(0) var<uniform> u: Uniforms;
          struct VIn { @location(0) pos: vec2<f32>, @location(1) color: vec4<f32> };
          struct VOut { @builtin(position) pos: vec4<f32>, @location(0) color: vec4<f32> };
          
          @vertex fn vs_main(in: VIn) -> VOut {
             var out: VOut;
             let x = (in.pos.x / u.cw) * 2.0 - 1.0;
             let y = 1.0 - (in.pos.y / u.ch) * 2.0;
             out.pos = vec4<f32>(x, y, 0.0, 1.0);
             out.color = in.color;
             return out;
          }
          
          @fragment fn fs_main(in: VOut) -> @location(0) vec4<f32> {
             return in.color;
          }
        `}),f=c.createRenderPipeline({layout:"auto",vertex:{module:U,entryPoint:"vs_main",buffers:[{arrayStride:24,attributes:[{shaderLocation:0,offset:0,format:"float32x2"},{shaderLocation:1,offset:8,format:"float32x4"}]}]},fragment:{module:U,entryPoint:"fs_main",targets:[{format:W,blend:{color:{srcFactor:"src-alpha",dstFactor:"one-minus-src-alpha",operation:"add"},alpha:{srcFactor:"one",dstFactor:"one-minus-src-alpha",operation:"add"}}}]},primitive:{topology:"triangle-list"}}),l=c.createBuffer({size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),v=c.createBuffer({size:5e4*36*4,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});r.current.drawingPipeline=f,r.current.drawingUniformBuffer=l,r.current.drawingBuffer=v,r.current.drawingBindGroup=c.createBindGroup({layout:f.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:l}}]}),Ee&&Ee(),requestAnimationFrame(ie)}catch{Qe("WebGPU Adapter failed to initialize. Your browser may have WebGPU disabled. Please open a new tab, go to chrome://flags/#enable-unsafe-webgpu , Enable it, and Relaunch Chrome.")}}return w(),()=>{a=!1,ge.current&&cancelAnimationFrame(ge.current),r.current.device&&(r.current.deviceLost=!0,r.current.device.destroy())}},[]);const ie=()=>{if(!r.current.device||!r.current.pipeline||r.current.deviceLost||!pe.current)return;const a=pe.current.width||n.current.width*x,w=pe.current.height||n.current.height*x;if(a<=0||w<=0)return;const P=50*x,D=w-24*x;let c=[],V=[];if(H&&!n.current.manualPriceScale&&i&&i.length>0){let t=1/0,e=-1/0;const d=Math.max(0,Math.min(i.length-1,Math.floor(n.current.logicalRange.from))),M=Math.max(0,Math.min(i.length-1,Math.ceil(n.current.logicalRange.to)));for(let p=d;p<=M;p++){const m=i[p];m&&Number.isFinite(m.low)&&Number.isFinite(m.high)&&(m.low<t&&(t=m.low),m.high>e&&(e=m.high))}if(t===1/0||e===-1/0)for(let p=0;p<i.length;p++){const m=i[p];m&&Number.isFinite(m.low)&&Number.isFinite(m.high)&&(m.low<t&&(t=m.low),m.high>e&&(e=m.high))}if(t!==1/0&&e!==-1/0){let p=(e-t)*.1;p===0&&(p=e*.01||1);const m=t-p,u=e+p,C=m-n.current.priceRange.min,U=u-n.current.priceRange.max;(Math.abs(C)>1e-6||Math.abs(U)>1e-6)&&(n.current.priceRange.min+=C*.4,n.current.priceRange.max+=U*.4,ge.current=requestAnimationFrame(ie))}}const W=te?[...i,te]:i;if(W&&W.length>0){const t=Math.min(W.length,r.current.maxCandles||1e5),e=new Float32Array(t*8);for(let d=0;d<t;d++){const M=W[d],p=d*8;e[p]=M.open,e[p+1]=M.high,e[p+2]=M.low,e[p+3]=M.close,e[p+4]=d,e[p+5]=M.isPrediction?1:0}r.current.candleBuffer&&(r.current.device.queue.writeBuffer(r.current.candleBuffer,0,e),r.current.candleCount=t)}const N=n.current.logicalRange,ne=N.to-N.from||1,{min:F,max:Z}=n.current.priceRange,me=Z-F||1,he=(a-P)/(ne*10),B=D/me,oe=-(N.from*10*he),Q=0,fe=new Float32Array([he,B,oe,Q,a,w,F,Z]);r.current.device.queue.writeBuffer(r.current.uniformBuffer,0,fe);let J=0;if(r.current.charMap&&r.current.textStorageBuffer){const t=new Float32Array(r.current.maxChars*8),e=(R,G,ee)=>{for(let z=0;z<R.length;z++){const Ae=R[z],le=r.current.charMap[Ae];if(!le)continue;if(J>=r.current.maxChars)break;const de=J*8,Re=le.w-8*2;t[de]=G-8,t[de+1]=ee-le.h/2,t[de+2]=0,t[de+3]=0,t[de+4]=le.x,t[de+5]=le.y,t[de+6]=le.w,t[de+7]=le.h,G+=Re,J++}},d=n.current.logicalRange,M=Math.max(0,Math.floor(d.from)),p=Math.min(i.length-1,Math.ceil(d.to)),{min:m,max:u}=n.current.priceRange,C=u-m||1,U=Math.max(4,Math.floor(w/(60*x))),f=C/U,l=Math.pow(10,Math.floor(Math.log10(f))),v=f/l;let h=1;v>7.5?h=10:v>3.5?h=5:v>1.5&&(h=2);const o=Math.max(1e-6,h*l),g=o>=1?0:o>=.1||o>=.01?2:o>=.001?3:4,s=R=>{let G=0;const ee=8;for(let Y=0;Y<R.length;Y++){const z=r.current.charMap[R[Y]];z&&(G+=z.w-ee*2)}return G};let S=36*x;const L=Math.floor(m/o)*o;for(let R=L;R<=u;R+=o){if(R<m||R>u)continue;const G=s(R.toFixed(g));G>S&&(S=G)}const A=S+16*x;n.current.pAxisW=A/x;const b=d.to-d.from||1,re=(a-A)/(b*10),ce=-(d.from*10*re),De=[];let We=-1,ze=-1;for(let R=M;R<=p;R++){if(!i[R])continue;const G=i[R].time,ee=G<1e10?G*1e3:G,Y=new Date(ee),z=Y.getUTCMonth(),Ae=Y.getUTCDate(),le=Y.getUTCHours(),de=Y.getUTCMinutes(),Re=z!==We&&We!==-1,tt=Ae!==ze&&ze!==-1&&!Re;We=z,ze=Ae;const Le=Re&&Y.getUTCMonth()===0;let Ye=!1,Ge="";if(Le)Ge=Y.getUTCFullYear().toString(),Ye=!0;else if(Re)Ge=Y.toLocaleString("default",{month:"short",timeZone:"UTC"}),Ye=!0;else if(tt)Ge=`${Y.getUTCDate()} ${Y.toLocaleString("default",{month:"short",timeZone:"UTC"})}`,Ye=!0;else{const it=Math.max(1,Math.floor((d.to-d.from||1)/12));if(R%it!==0)continue;Ge=`${le.toString().padStart(2,"0")}:${de.toString().padStart(2,"0")}`}const nt=Math.max(1,10*re*.8),rt=R*10*re+ce+nt*.5;De.push({x:rt,label:Ge,isMajor:Ye})}c=pt({timeLabels:De,cW:a,pAxisW:A});const Pe=R=>{let G=0;const ee=8;for(let Y=0;Y<R.length;Y++){const z=r.current.charMap[R[Y]];z&&z.h-ee*2>G&&(G=z.h-ee*2)}return G||12*x},Me=(c.length>0?Math.max(...c.map(R=>Pe(R.label))):12*x)+16*x,ve=w-Me;n.current.timeAxisH=Me/x;const $e=ve/C,Xe=[];for(let R=L;R<=u;R+=o){if(R<m||R>u)continue;const G=ve-(R-m)*$e;Xe.push({y:G,p:R,label:R.toFixed(g)})}V=gt({priceLabels:Xe,cH:w,timeAxisH:Me}),c.forEach(({x:R,label:G})=>{const ee=s(G);e(G,Math.round(R-ee/2),Math.round(ve+Me/2))}),V.forEach(({y:R,label:G})=>{const ee=s(G),Y=Math.floor(11*x),z=Math.round(a-A+(A-ee)/2);e(G,z,Math.round(R-Y/2))});let Fe=-1;if(i.length>0){const R=i[i.length-1],G=n.current.priceRange.min,ee=n.current.priceRange.max,Y=ee-G>0?ve/(ee-G):1;if(Fe=ve-(R.close-G)*Y,Fe>=0&&Fe<=ve){const z=R.close.toFixed(g),Ae=s(z),le=Math.round(a-A+(A-Ae)/2);e(z,le,Math.round(Fe))}}const et=n.current.hoverPixel;if(et){const R=et.x*x,G=et.y*x;if(R>=0&&R<=a-A&&G>=0&&G<=ve){const Y=(u-G/$e).toFixed(g),z=s(Y),Ae=Math.round(a-A+(A-z)/2);e(Y,Ae,Math.round(G));const le=d.from+R/(a-A)*b,de=Math.min(i.length-1,Math.max(0,Math.floor(le))),Re=i[de];if(Re){const tt=Re.time<1e10?Re.time*1e3:Re.time,Le=new Date(tt),Ye=Le.getDate().toString().padStart(2,"0"),Ge=Le.toLocaleString("en-US",{month:"short"}),nt=Le.getFullYear().toString().slice(-2),rt=Le.getHours().toString().padStart(2,"0"),it=Le.getMinutes().toString().padStart(2,"0"),st=`${Ye} ${Ge} '${nt} ${rt}:${it}`,ft=s(st);e(st,Math.round(R-ft/2),Math.round(ve+Me/2))}}}if(J>0){r.current.device.queue.writeBuffer(r.current.textStorageBuffer,0,t);const R=$?[.788,.82,.851,1]:[.075,.09,.133,1];r.current.device.queue.writeBuffer(r.current.textUniformBuffer,0,new Float32Array([a,w,0,0,...R]))}}const ae=r.current.device.createCommandEncoder();r.current.computePipeline&&r.current.candleCount>0;const xe=r.current.context.getCurrentTexture().createView(),y=ae.beginRenderPass({colorAttachments:[{view:xe,clearValue:{r:.051,g:.067,b:.09,a:1},loadOp:"clear",storeOp:"store"}]});if(r.current.gridPipeline){const t=n.current.hoverPixel?n.current.hoverPixel.x*x:-1,e=n.current.hoverPixel?n.current.hoverPixel.y*x:-1,d=(n.current.pAxisW||65)*x,M=(n.current.timeAxisH||28)*x,p=Math.max(24*x,(a-d)/10),m=Math.max(18*x,(w-M)/8);let u=-1,C=-1,U=0,f=0,l=0;if(i&&i.length>0){const h=i.length-1,o=i[h],g=o.close>=o.open;U=g?.031:.949,f=g?.6:.211,l=g?.505:.27;const s=n.current.priceRange.min,S=n.current.priceRange.max,L=S-s>0?(w-M)/(S-s):1;u=w-M-(o.close-s)*L;const A=n.current.logicalRange,b=A.to-A.from,re=(h-A.from)/b*(a-d),ce=(a-d)/b,De=Math.max(1,10*ce*.8);C=re+De/2+.5}const v=new Float32Array([a,w,t,e,p,m,oe,Q,d,M,u,C,U,f,l,1]);r.current.device.queue.writeBuffer(r.current.gridUniformBuffer,0,v),y.setPipeline(r.current.gridPipeline),y.setBindGroup(0,r.current.gridBindGroup),y.draw(6)}let I=0;r.current.device.queue.writeBuffer(r.current.drawingUniformBuffer,0,new Float32Array([a,w,0,0]));const E=c.length+V.length+2;if(E>0){const t=E*36,e=new Float32Array(t);let d=0;const M=(u,C,U,f)=>{const l=Ke(u,C,U);for(const v of l)e[d++]=v.x,e[d++]=v.y,e[d++]=f[0],e[d++]=f[1],e[d++]=f[2],e[d++]=f[3]},p=$?[.168,.184,.223,1]:[.878,.89,.921,1];c.forEach(({x:u})=>M({x:u,y:0},{x:u,y:D},1,p)),V.forEach(({y:u})=>M({x:0,y:u},{x:a-P,y:u},1,p)),M({x:a-P,y:0},{x:a-P,y:D},1,p),M({x:0,y:D},{x:a-P,y:D},1,p);const m=e.byteLength;r.current.device.queue.writeBuffer(r.current.drawingBuffer,I,e.buffer,e.byteOffset,m),y.setPipeline(r.current.drawingPipeline),y.setBindGroup(0,r.current.drawingBindGroup),y.setVertexBuffer(0,r.current.drawingBuffer,I),y.draw(d/6),I+=m,I=Math.ceil(I/4)*4}if(i&&i.length>0){const t=n.current.logicalRange,e=Math.max(0,Math.floor(t.from)),d=Math.min(i.length-1,Math.ceil(t.to));let M=0;for(let p=e;p<=d;p++)i[p]&&i[p].volume>M&&(M=i[p].volume);if(M>0&&d>=e){const m=(d-e+1)*36,u=new Float32Array(m);let C=0;const U=t.to-t.from||1,f=(a-P)/(U*10),l=-(t.from*10*f),v=10*f,h=Math.max(1,v*.8),o=(g,s,S,L)=>{const A=Ke(g,s,S);for(const b of A)u[C++]=b.x,u[C++]=b.y,u[C++]=L[0],u[C++]=L[1],u[C++]=L[2],u[C++]=L[3]};for(let g=e;g<=d;g++){const s=i[g];if(!s)continue;const S=g*10*f+l+h*.5,L=s.volume/M*(w*.15),A=s.close>=s.open,b=A?16/255:239/255,re=A?185/255:68/255,ce=A?129/255:68/255;o({x:S,y:D},{x:S,y:D-L},h,[b,re,ce,.35])}if(C>0){const g=Math.max(1,Math.floor(a-P)),s=Math.max(1,Math.floor(D));y.setScissorRect(0,0,g,s);const S=u.byteLength;r.current.device.queue.writeBuffer(r.current.drawingBuffer,I,u.buffer,u.byteOffset,S),y.setPipeline(r.current.drawingPipeline),y.setBindGroup(0,r.current.drawingBindGroup),y.setVertexBuffer(0,r.current.drawingBuffer,I),y.draw(C/6),I+=S,I=Math.ceil(I/4)*4,y.setScissorRect(0,0,Math.floor(a),Math.floor(w))}}}if(y.setPipeline(r.current.pipeline),y.setBindGroup(0,r.current.bindGroup),r.current.candleCount>0){const t=Math.max(1,Math.floor(a-P)),e=Math.max(1,Math.floor(D));y.setScissorRect(0,0,t,e),y.draw(12,r.current.candleCount,0,0),y.setScissorRect(0,0,Math.floor(a),Math.floor(w))}if(r.current.drawingPipeline&&i&&i.length>0){const t=new Float32Array(2304);let e=0;const d=(f,l,v,h,o)=>{e+36>t.length||(t[e++]=f,t[e++]=l,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=v,t[e++]=l,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=f,t[e++]=h,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=f,t[e++]=h,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=v,t[e++]=l,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=v,t[e++]=h,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3])},M=(f,l,v,h,o)=>{if(e+36>t.length)return;const g=1*x,s=v-f,S=h-l,L=Math.sqrt(s*s+S*S)||1,A=-S/L*(g/2),b=s/L*(g/2);t[e++]=f-A,t[e++]=l-b,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=f+A,t[e++]=l+b,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=v-A,t[e++]=h-b,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=v-A,t[e++]=h-b,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=f+A,t[e++]=l+b,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3],t[e++]=v+A,t[e++]=h+b,t[e++]=o[0],t[e++]=o[1],t[e++]=o[2],t[e++]=o[3]},p=[1,1,1,.3],m=$?[.165,.18,.224,1]:[.878,.89,.922,1];let u=-1,C=!0;if(i.length>0){const f=i[i.length-1];C=f.close>=f.open;const l=n.current.priceRange.min,v=n.current.priceRange.max,h=v-l>0?D/(v-l):1;u=D-(f.close-l)*h}if(u>=0&&u<=D){const v=C?[.031,.6,.505,1]:[.949,.211,.27,1];d(a-P,u-10*x,a,u+10*x,v)}const U=n.current.hoverPixel;if(U){const f=U.x*x,l=U.y*x;if(f>=0&&f<=a-P&&l>=0&&l<=D){M(f,0,f,D,p),M(0,l,a-P,l,p),d(a-P,l-11*x,a,l+11*x,m);const v=(n.current.timeAxisH||28)*x;d(f-60*x,D,f+60*x,D+v,m)}}if(e>0){const f=new Float32Array(t.buffer,0,e),l=f.byteLength;r.current.device.queue.writeBuffer(r.current.drawingBuffer,I,f.buffer,f.byteOffset,l),y.setPipeline(r.current.drawingPipeline),y.setBindGroup(0,r.current.drawingBindGroup),y.setVertexBuffer(0,r.current.drawingBuffer,I),y.draw(e/6),I+=l,I=Math.ceil(I/4)*4}}if(r.current.textPipeline&&J>0&&(y.setPipeline(r.current.textPipeline),y.setBindGroup(0,r.current.textBindGroup),y.draw(6,J,0,0)),r.current.drawingPipeline&&i&&i.length>1&&we&&we.length>0){const t=(n.current.pAxisW||65)*x,e=w-(n.current.timeAxisH||28)*x,{min:d,max:M}=n.current.priceRange,p=M-d||1,m=e/p,u=n.current.logicalRange,C=u.to-u.from||1,U=o=>(Ue(o,i)-u.from)/C*(a-t),f=o=>e-(o-d)*m,l=["#ff9800","#2962ff","#26a69a","#e040fb","#00e676","#ff5722","#00bcd4","#9c27b0"];let v=0;const h=[];if(we.forEach((o,g)=>{if(!o.visible)return;const s=mt[o.type];if(!s||s.kind!=="overlay")return;const S=ke[o.id];S&&s.seriesConfig.forEach((L,A)=>{const b=S[L.key];if(!b||b.length<2)return;const re=o.color||(L.options?L.options(o.params||s.defaultParams,o.color)?.color:null)||l[(g+A)%l.length];let ce=1,De=.6,We=0,ze=1;if(re&&re.startsWith("#")){const Pe=re.replace("#","");ce=parseInt(Pe.substring(0,2),16)/255,De=parseInt(Pe.substring(2,4),16)/255,We=parseInt(Pe.substring(4,6),16)/255}for(let Pe=1;Pe<b.length;Pe++){const Ne=b[Pe-1],Me=b[Pe];if(Ne.value==null||Me.value==null||isNaN(Ne.value)||isNaN(Me.value))continue;const ve=U(Ne.time),$e=f(Ne.value),Xe=U(Me.time),Fe=f(Me.value);Xe<0||ve>a-t||(h.push({x1:ve,y1:$e,x2:Xe,y2:Fe,r:ce,g:De,b:We,a:ze}),v++)}})}),v>0){const o=v*36,g=new Float32Array(o);let s=0;for(const b of h){const re=Ke({x:b.x1,y:b.y1},{x:b.x2,y:b.y2},1.5*x);for(const ce of re)g[s++]=ce.x,g[s++]=ce.y,g[s++]=b.r,g[s++]=b.g,g[s++]=b.b,g[s++]=b.a}const S=Math.max(1,Math.floor(a-t)),L=Math.max(1,Math.floor(e));y.setScissorRect(0,0,S,L);const A=g.byteLength;r.current.device.queue.writeBuffer(r.current.drawingBuffer,I,g.buffer,g.byteOffset,A),y.setPipeline(r.current.drawingPipeline),y.setBindGroup(0,r.current.drawingBindGroup),y.setVertexBuffer(0,r.current.drawingBuffer,I),y.draw(s/6),I+=A,I=Math.ceil(I/4)*4,y.setScissorRect(0,0,Math.floor(a),Math.floor(w))}}if(r.current.drawingPipeline){const t=(n.current.pAxisW||65)*x,e=w-(n.current.timeAxisH||28)*x,{min:d,max:M}=n.current.priceRange,p=M-d>0?e/(M-d):1,m=n.current.logicalRange,u=m.to-m.from,C=l=>(Ue(l,i)-m.from)/u*(a-t),U=l=>e-(l-d)*p;let f=0;if(_&&_.length>0)for(let l=0;l<_.length;l++)_[l].tool==="trendline"&&_[l].points.length>=2&&f++;if(O==="trendline"&&r.current.activeDrawStart&&r.current.activeTempShape&&f++,f>0){const l=f*36,v=new Float32Array(l);let h=0;const o=(S,L,A,b)=>{const re=Ke(S,L,A);for(const ce of re)v[h++]=ce.x,v[h++]=ce.y,v[h++]=b[0],v[h++]=b[1],v[h++]=b[2],v[h++]=b[3]},g=[.2,.6,1,1];if(_&&_.length>0)for(let S=0;S<_.length;S++){const L=_[S];if(L.tool==="trendline"&&L.points.length>=2){const A={x:C(L.points[0].time),y:U(L.points[0].price)},b={x:C(L.points[1].time),y:U(L.points[1].price)};o(A,b,2*x,g)}}if(O==="trendline"&&r.current.activeDrawStart&&r.current.activeTempShape){const S={x:C(r.current.activeDrawStart.time),y:U(r.current.activeDrawStart.price)},L={x:C(r.current.activeTempShape.time),y:U(r.current.activeTempShape.price)};o(S,L,2*x,g)}const s=v.byteLength;r.current.device.queue.writeBuffer(r.current.drawingBuffer,I,v.buffer,v.byteOffset,s),y.setPipeline(r.current.drawingPipeline),y.setBindGroup(0,r.current.drawingBindGroup),y.setVertexBuffer(0,r.current.drawingBuffer,I),y.draw(h/6)}}y.end(),r.current.device.queue.submit([ae.finish()]),Ie&&Ie()};return j.useEffect(()=>{if(!Oe.current)return;const a=new ResizeObserver(w=>{for(let P of w){const{width:D,height:c}=P.contentRect;if(n.current.width=D,n.current.height=c,pe.current&&(pe.current.width=Math.floor(D*x),pe.current.height=Math.floor(c*x)),H&&i.length>0){let V=1/0,W=-1/0;const N=Math.max(0,Math.floor(n.current.logicalRange.from)),ne=Math.min(i.length-1,Math.ceil(n.current.logicalRange.to));for(let F=N;F<=ne;F++)i[F].low<V&&(V=i[F].low),i[F].high>W&&(W=i[F].high);if(V!==1/0&&W!==-1/0){let F=(W-V)*.1;F===0&&(F=W*.01||1),n.current.priceRange={min:V-F,max:W+F}}}requestAnimationFrame(ie)}});return a.observe(Oe.current),()=>a.disconnect()},[i,H]),j.useEffect(()=>{H&&(n.current.manualPriceScale=!1),requestAnimationFrame(ie)},[H]),j.useEffect(()=>{const a=Oe.current;if(!a)return;let w=!1,P=0,D=0,c=0,V=0,W=0,N=0;const ne=B=>{const{left:oe,top:Q}=a.getBoundingClientRect(),fe=B.clientX-oe,J=B.clientY-Q,ae=n.current.width,xe=n.current.height,y=n.current.pAxisW||65,I=fe>ae-y||J>xe-(n.current.timeAxisH||28);if(!I&&O==="eraser"){const{left:E,top:t}=a.getBoundingClientRect(),e=B.clientX-E,d=B.clientY-t,{min:M,max:p}=n.current.priceRange,m=p-M,u=n.current.height,C=m>0?(u-(n.current.timeAxisH||28))/m:1,U=g=>(p-g)*C,f=n.current.width,l=n.current.logicalRange,v=l.to-l.from,o=vt(_,e,d,g=>{const s=Ue(g,i),S=n.current.pAxisW||65;return(s-l.from)/v*(f-S)},U,8);o&&Se&&Se(o.id);return}if(!I&&O&&O!=="cursor"){const{left:E,top:t}=a.getBoundingClientRect(),e=B.clientX-E,d=B.clientY-t,{min:M,max:p}=n.current.priceRange,m=p-M,u=n.current.height,C=m>0?(u-(n.current.timeAxisH||28))/m:1,U=p-d/C,f=n.current.width,l=n.current.logicalRange,v=l.to-l.from,h=n.current.pAxisW||65,o=l.from+e/(f-h)*v,s={time:i[Math.min(i.length-1,Math.max(0,Math.floor(o)))]?.time||0,price:U};r.current.activeDrawStart?(Be&&Be({id:Date.now().toString(),tool:O,points:[r.current.activeDrawStart,s]}),r.current.activeDrawStart=null,r.current.activeTempShape=null):(r.current.activeDrawStart=s,r.current.activeTempShape=s),requestAnimationFrame(ie);return}w=!0,P=B.clientX,D=B.clientY,c=n.current.logicalRange.from,V=n.current.logicalRange.to,W=n.current.priceRange.min,N=n.current.priceRange.max,a.setPointerCapture(B.pointerId)},F=B=>{if(O&&O!=="cursor"&&r.current.activeDrawStart){const{left:y,top:I}=a.getBoundingClientRect(),E=B.clientX-y,t=B.clientY-I,{min:e,max:d}=n.current.priceRange,M=d-e,p=n.current.height,m=M>0?(p-(n.current.timeAxisH||28))/M:1,u=d-t/m,C=n.current.width,U=n.current.logicalRange,f=U.to-U.from,l=U.from+E/(C-(n.current.pAxisW||65))*f,v=Math.min(i.length-1,Math.max(0,Math.floor(l))),h=i[v],o=h?.time||0;let g=u;if(h){const s=Math.abs(u-h.open),S=Math.abs(u-h.high),L=Math.abs(u-h.low),A=Math.abs(u-h.close),b=Math.min(s,S,L,A);b===s?g=h.open:b===S?g=h.high:b===L?g=h.low:g=h.close}n.current.hoverPixel={x:E/x,y:t/x},r.current.activeTempShape={time:o,price:g},requestAnimationFrame(ie);return}if(!w&&(!O||O==="cursor")){const{left:y,top:I}=a.getBoundingClientRect(),E=B.clientX-y,t=B.clientY-I,{min:e,max:d}=n.current.priceRange,M=d-e,p=n.current.height;M>0&&(p-(n.current.timeAxisH||28))/M;const m=n.current.width,u=n.current.logicalRange,C=u.to-u.from,U=u.from+E/(m-(n.current.pAxisW||65))*C,f=Math.min(i.length-1,Math.max(0,Math.floor(U)));i[f]?.time,n.current.hoverPixel={x:E/x,y:t/x};const v=36*x;m-(n.current.pAxisW||65)+((n.current.pAxisW||65)-v)/2,ge.current=requestAnimationFrame(ie);return}if(!w)return;const oe=B.clientX-P,Q=B.clientY-D,fe=n.current.width,ae=(V-c)/fe,xe=oe*ae;if(n.current.logicalRange.from=c-xe,n.current.logicalRange.to=V-xe,Math.abs(Q)>2&&(n.current.manualPriceScale=!0),n.current.manualPriceScale){const y=n.current.height,I=N-W||1,E=(y-(n.current.timeAxisH||28))/I,t=Q/E;n.current.priceRange.min=W+t,n.current.priceRange.max=N+t}K&&i&&i.length>0&&K({from:i[Math.max(0,Math.floor(n.current.logicalRange.from))]?.time,to:i[Math.min(i.length-1,Math.ceil(n.current.logicalRange.to))]?.time}),ge.current=requestAnimationFrame(ie)},Z=B=>{w=!1,a.releasePointerCapture(B.pointerId)},me=B=>{B.preventDefault();const oe=a.getBoundingClientRect(),Q=n.current.width,fe=n.current.logicalRange.to-n.current.logicalRange.from;if(Math.abs(B.deltaX)>Math.abs(B.deltaY)){const J=fe/Q,ae=B.deltaX*.5*J;n.current.logicalRange.from+=ae,n.current.logicalRange.to+=ae}else{const J=Math.max(0,Math.min(Q,B.clientX-oe.left)),ae=n.current.pAxisW||65,xe=Math.max(1,Q-ae),y=Math.max(0,Math.min(1,J/xe));let I;B.ctrlKey?I=Math.exp(B.deltaY*.015):I=Math.exp(B.deltaY*.0018);const E=n.current.logicalRange.from+fe*y,t=Math.max(5,Math.min(5e4,fe*I));n.current.logicalRange.from=E-t*y,n.current.logicalRange.to=E+t*(1-y)}K&&i&&i.length>0&&K({from:i[Math.max(0,Math.floor(n.current.logicalRange.from))]?.time,to:i[Math.min(i.length-1,Math.ceil(n.current.logicalRange.to))]?.time}),ge.current=requestAnimationFrame(ie)},he=B=>{w=!1,n.current.hoverPixel=null,ge.current=requestAnimationFrame(ie)};return a.addEventListener("pointerdown",ne),a.addEventListener("pointermove",F),a.addEventListener("pointerup",Z),a.addEventListener("pointercancel",Z),a.addEventListener("pointerleave",he),a.addEventListener("wheel",me,{passive:!1}),()=>{a.removeEventListener("pointerdown",ne),a.removeEventListener("pointermove",F),a.removeEventListener("pointerup",Z),a.removeEventListener("pointercancel",Z),a.removeEventListener("pointerleave",he),a.removeEventListener("wheel",me)}},[i,O,K]),j.useImperativeHandle(T,()=>({render:()=>requestAnimationFrame(ie),scrollToRealTime:()=>{if(!i||i.length===0)return;const a=i.length-1,w=n.current.logicalRange.to-n.current.logicalRange.from||100,P=w*.2;n.current.logicalRange.from=a-w+P,n.current.logicalRange.to=a+P,n.current.manualPriceScale=!1,requestAnimationFrame(ie),K&&K({from:i[Math.max(0,Math.floor(n.current.logicalRange.from))]?.time,to:i[Math.min(i.length-1,Math.ceil(n.current.logicalRange.to))]?.time})},timeScale:()=>({getVisibleLogicalRange:()=>n.current.logicalRange,getVisibleRange:()=>null,fitContent:()=>{}}),priceScale:()=>({applyOptions:()=>{}}),captureViewport:()=>({logicalRange:n.current.logicalRange}),applyViewport:a=>{a&&a.logicalRange&&(n.current.logicalRange=a.logicalRange)},getPixel:(a,w)=>{const P=n.current.width*x,D=n.current.height*x,c=(n.current.pAxisW||65)*x,V=D-28*x,{min:W,max:N}=n.current.priceRange,ne=N-W,F=ne>0?V/ne:1,Z=n.current.logicalRange,me=Z.to-Z.from,B=(Ue(a,i)-Z.from)/me*(P-c),oe=V-(w-W)*F;return{x:B/x,y:oe/x}},coordinateToTimePrice:(a,w)=>{if(!i||i.length===0)return null;const P=n.current.width,D=n.current.height,c=n.current.pAxisW||65,V=D-28,W=P-c,N=n.current.logicalRange,ne=N.to-N.from,F=Math.round(N.from+a/W*ne),Z=Math.max(0,Math.min(i.length-1,F)),me=i[Z]?.time||0,{min:he,max:B}=n.current.priceRange,oe=B-he,Q=B-w/(V/oe);return{time:me,price:Q}}})),j.useEffect(()=>{Te&&Ve&&Ve()},[Te,Ve]),Te?Ce.jsxs("div",{className:"w-full h-full flex items-center justify-center bg-[#131722] text-sm font-medium p-4 text-center",children:[Ce.jsx("span",{className:"w-4 h-4 mr-2 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"}),Ce.jsx("span",{className:"text-amber-300",children:"Switching to WebGL Engine..."})]}):Ce.jsxs("div",{ref:Oe,className:"w-full h-full relative bg-[#131722] overflow-hidden cursor-crosshair",children:[Ce.jsx("canvas",{ref:pe,className:"absolute top-0 left-0 w-full h-full touch-none"}),Ce.jsxs("div",{className:"absolute top-2 left-2 z-10 pointer-events-none flex items-center space-x-2 bg-slate-950/80 backdrop-blur border border-cyan-500/30 px-2.5 py-1 rounded text-[11px] font-mono text-cyan-300 shadow-lg",children:[Ce.jsx("span",{className:"w-2 h-2 rounded-full bg-emerald-400 animate-pulse"}),Ce.jsxs("span",{children:["WEBGPU HARDWARE: ",lt]})]})]})});export{Gt as default};
