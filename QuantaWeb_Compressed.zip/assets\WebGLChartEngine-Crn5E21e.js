import{r as F,j as Ht}from"./vendor-react-RtAl1mHH.js";import{c as Qt,a as jt,I as Kt}from"./WebContainer-DLuE-P7q.js";import"./vendor-core-DGlKcvj2.js";import"./index-DT5o_RTH.js";import"./vendor-icons-DLPYUNUd.js";import"./vendor-charts-CCdQvjV5.js";import"./exchanges-Df4GuvII.js";import"./vendor-recharts-DpnGRxRv.js";function Zt(r="'Inter', 'SF Pro Display', -apple-system, sans-serif",st=11,Y=1){const k=`0123456789.:-+$%/ '\\()[]{}*!?@#&_~<>|,"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz`,$=document.createElement("canvas");$.width=512,$.height=512;const tt=$.getContext("2d",{willReadFrequently:!0});if(!tt)throw new Error("Could not create 2D context for HD Glyph generation");tt.clearRect(0,0,512,512);const ht=Math.floor(st*Y);tt.font=`600 ${ht}px ${r}`,tt.textBaseline="top",tt.textAlign="left",tt.fillStyle="#ffffff";const et={},z=Math.ceil(2*Y);let gt=z,yt=z;for(let Q=0;Q<k.length;Q++){const Mt=k[Q],dt=tt.measureText(Mt),j=Math.ceil(dt.width),K=Math.ceil(ht*1.3),H=j+z*2,S=K+z*2;gt+H>512&&(gt=z,yt+=S),tt.fillText(Mt,gt+z,yt+z),et[Mt]={x:gt+z,y:yt+z,w:j,h:K,cellW:H,cellH:S},gt+=H}const At=tt.getImageData(0,0,512,512).data,bt=new Uint8Array(512*512);for(let Q=0;Q<512*512;Q++)bt[Q]=At[Q*4+3];return{alphaData:bt,charMap:et,atlasSize:512,dpr:Y}}const Jt=`#version 300 es
in vec2 a_position;
out vec2 v_fragPos;
uniform vec2 u_resolution;

void main() {
    gl_Position = vec4(a_position, 0.0, 1.0);
    v_fragPos = vec2((a_position.x + 1.0) * 0.5 * u_resolution.x, (1.0 - a_position.y) * 0.5 * u_resolution.y);
}
`,te=`#version 300 es
precision highp float;
in vec2 v_fragPos;
out vec4 fragColor;
uniform vec2 u_resolution;
uniform float u_livePixelY;
uniform vec4 u_liveColor;
uniform float u_darkMode;
uniform vec2 u_axisSize;

void main() {
    vec2 coord = v_fragPos;
    
    // Axis background
    if (coord.x > (u_resolution.x - u_axisSize.x) || coord.y > (u_resolution.y - u_axisSize.y)) {
        if (u_darkMode > 0.5) {
            fragColor = vec4(0.051, 0.067, 0.090, 1.0); // #0d1117
        } else {
            fragColor = vec4(1.0, 1.0, 1.0, 1.0); // #ffffff
        }
        return;
    }

    vec4 finalColor = vec4(0.0, 0.0, 0.0, 0.0);

    // Live Price dashed line
    if (u_livePixelY > 0.0 && coord.x < (u_resolution.x - u_axisSize.x)) {
        float distY = abs(coord.y - u_livePixelY);
        if (distY < 1.0) {
            if (int(coord.x) % 8 < 4) {
                finalColor = vec4(u_liveColor.rgb, 0.8);
            }
        }
    }
    
    fragColor = finalColor;
}
`,ee=`#version 300 es
in vec2 a_position; // unit quad vertex
in vec4 a_candlePrices; // open, high, low, close
in vec2 a_candleMeta; // index, isPrediction

uniform vec2 u_resolution;
uniform vec2 u_scale;
uniform vec2 u_offset;
uniform vec2 u_priceRange;
uniform float u_isWick;

out vec4 v_color;

void main() {
    float open = a_candlePrices.x;
    float high = a_candlePrices.y;
    float low = a_candlePrices.z;
    float close = a_candlePrices.w;
    float index = a_candleMeta.x;
    float isPrediction = a_candleMeta.y;

    float spacing = 10.0 * u_scale.x;
    float candleWidth = max(1.0, floor(spacing * 0.8));
    float wickWidth = max(1.0, floor(min(2.0, spacing * 0.1)));

    float topP = max(open, close);
    float botP = min(open, close);
    if (u_isWick > 0.5) {
        topP = high;
        botP = low;
    }

    float pixelYTop = floor((u_priceRange.y - topP) * u_scale.y + u_offset.y);
    float pixelYBot = floor((u_priceRange.y - botP) * u_scale.y + u_offset.y);
    if (u_isWick < 0.5 && (pixelYBot - pixelYTop) < 1.0) {
        pixelYBot = pixelYTop + 1.0;
    }

    float heightPx = max(1.0, pixelYBot - pixelYTop);
    float widthPx = (u_isWick > 0.5) ? wickWidth : candleWidth;
    float xOffset = (u_isWick > 0.5) ? floor((candleWidth - wickWidth) * 0.5) : 0.0;

    float pixelX = floor((index * 10.0 * u_scale.x) + u_offset.x) + xOffset;
    float pixelY = pixelYTop;

    vec2 pos = vec2(pixelX, pixelY) + a_position * vec2(widthPx, heightPx);
    // --- MANUAL PIXEL SNAPPING ---
    float snappedX = round(pos.x) + 0.5;
    float snappedY = round(pos.y) + 0.5;
    
    float clipX = (snappedX / u_resolution.x) * 2.0 - 1.0;
    float clipY = 1.0 - (snappedY / u_resolution.y) * 2.0;

    gl_Position = vec4(clipX, clipY, 0.0, 1.0);

    bool isUp = close >= open;
    vec4 color = isUp ? vec4(0.031, 0.600, 0.505, 1.0) : vec4(0.949, 0.212, 0.271, 1.0);
    if (isPrediction > 0.5) {
        color.a = 0.45;
    }
    v_color = color;
}
`,re=`#version 300 es
precision mediump float;
in vec4 v_color;
out vec4 fragColor;

void main() {
    fragColor = v_color;
}
`,oe=`#version 300 es
in vec2 a_position;
in vec4 a_color;
uniform vec2 u_resolution;
out vec4 v_color;

void main() {
    // --- MANUAL PIXEL SNAPPING ---
    float snappedX = round(a_position.x) + 0.5;
    float snappedY = round(a_position.y) + 0.5;

    float clipX = (snappedX / u_resolution.x) * 2.0 - 1.0;
    float clipY = 1.0 - (snappedY / u_resolution.y) * 2.0;
    
    gl_Position = vec4(clipX, clipY, 0.0, 1.0);
    v_color = a_color;
}
`,ne=`#version 300 es
precision mediump float;
in vec4 v_color;
out vec4 fragColor;

void main() {
    fragColor = v_color;
}
`,ie=`#version 300 es
in vec2 a_position;
in vec2 a_uv;
uniform vec2 u_resolution;
out vec2 v_uv;

void main() {
    float clipX = (a_position.x / u_resolution.x) * 2.0 - 1.0;
    float clipY = 1.0 - (a_position.y / u_resolution.y) * 2.0;
    gl_Position = vec4(clipX, clipY, 0.0, 1.0);
    v_uv = vec2(a_uv.x, 1.0 - a_uv.y);
}
`,ae=`#version 300 es
precision mediump float;
in vec2 v_uv;
out vec4 fragColor;
uniform sampler2D u_fontTexture;
uniform vec4 u_textColor;

void main() {
    float alpha = texture(u_fontTexture, v_uv).r;
    // Crisp threshold for exact pixel rendering, preventing blur from sub-pixel linear interpolation
    float crispAlpha = smoothstep(0.40, 0.55, alpha); 
    if (crispAlpha < 0.01) { discard; }
    fragColor = vec4(u_textColor.rgb, u_textColor.a * crispAlpha);
}
`;function Ot(r,st,Y){const k=r.createShader(st);return r.shaderSource(k,Y),r.compileShader(k),r.getShaderParameter(k,r.COMPILE_STATUS)?k:(r.deleteShader(k),null)}function Dt(r,st,Y){const k=Ot(r,r.VERTEX_SHADER,st),Yt=Ot(r,r.FRAGMENT_SHADER,Y),$=r.createProgram();return r.attachShader($,k),r.attachShader($,Yt),r.linkProgram($),r.getProgramParameter($,r.LINK_STATUS)?$:null}const pe=F.forwardRef(({candles:r=[],predictedCandle:st=null,darkMode:Y=!0,chartStyle:k="candles",priceScaleMode:Yt=0,autoScale:$=!0,timezoneOffset:tt=0,initialVisibleRange:ht,onVisibleRangeChange:et,onChartReady:z,activeTool:gt=null,isHoveringDrawing:yt,drawings:St=[],visualIndicators:At=[],indicatorDataMap:bt={},onRequestDraw:Q},Mt)=>{const dt=F.useRef(null),j=F.useRef(null);F.useRef(null),F.useRef(null),F.useRef(null);const K=F.useRef(null),H=F.useRef({}),S=F.useRef({}),Et=F.useRef(null),Lt=F.useRef({}),o=F.useRef({logicalRange:{from:0,to:100},priceRange:{min:0,max:100},manualPriceScale:!1,width:800,height:600,isDragging:!1,dragStart:null,hoverPixel:null}),p=window.devicePixelRatio||1,Pt=(t,e)=>{if(!e||e.length===0)return 0;let v=0,h=e.length-1;for(;v<=h;){const P=v+h>>1;if(e[P].time===t)return P;e[P].time<t?v=P+1:h=P-1}return v};F.useEffect(()=>{if(!dt.current)return;const t=new ResizeObserver(e=>{for(let v of e){const{width:h,height:P}=v.contentRect;o.current.width=h,o.current.height=P,j.current&&(j.current.width=Math.floor(h*p),j.current.height=Math.floor(P*p)),requestAnimationFrame(rt)}});return t.observe(dt.current),()=>t.disconnect()},[r]);const Xt=F.useRef(!1);F.useEffect(()=>{if(!(Xt.current||!r||r.length===0)){if(Xt.current=!0,ht?.visibleRange){const t=Pt(ht.visibleRange.from,r),e=Pt(ht.visibleRange.to,r);o.current.logicalRange={from:t,to:e}}else o.current.logicalRange={from:Math.max(0,r.length-80),to:r.length-1+20};requestAnimationFrame(rt)}},[ht,r]),F.useEffect(()=>{const t=j.current;if(!t)return;const e=t.getContext("webgl2",{antialias:!0,alpha:!1,preserveDrawingBuffer:!0});if(!e)return;K.current=e,H.current.grid=Dt(e,Jt,te),H.current.candle=Dt(e,ee,re),H.current.line=Dt(e,oe,ne),H.current.sdfText=Dt(e,ie,ae);const v=new Float32Array([0,0,1,0,0,1,0,1,1,0,1,1]);S.current.quad=e.createBuffer(),e.bindBuffer(e.ARRAY_BUFFER,S.current.quad),e.bufferData(e.ARRAY_BUFFER,v,e.STATIC_DRAW);const h=new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]);S.current.fsQuad=e.createBuffer(),e.bindBuffer(e.ARRAY_BUFFER,S.current.fsQuad),e.bufferData(e.ARRAY_BUFFER,h,e.STATIC_DRAW),S.current.dynamic=e.createBuffer(),S.current.candlePrices=e.createBuffer(),S.current.candleMeta=e.createBuffer(),S.current.text=e.createBuffer();const{alphaData:P,charMap:L,atlasSize:D}=Zt("'Inter', 'SF Pro Display', -apple-system, sans-serif",11,p);Lt.current=L;const b=e.createTexture();return e.bindTexture(e.TEXTURE_2D,b),e.texImage2D(e.TEXTURE_2D,0,e.R8,D,D,0,e.RED,e.UNSIGNED_BYTE,P),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),Et.current=b,z&&z(),requestAnimationFrame(rt),()=>{e.deleteBuffer(S.current.quad),e.deleteBuffer(S.current.fsQuad),e.deleteBuffer(S.current.dynamic),e.deleteBuffer(S.current.candlePrices),e.deleteBuffer(S.current.candleMeta),e.deleteBuffer(S.current.text),e.deleteTexture(Et.current)}},[]);const rt=()=>{const t=K.current;if(!t||!j.current)return;const e=j.current.width,v=j.current.height;if(e<=0||v<=0)return;let h=v-28*p;t.viewport(0,0,e,v),Y?t.clearColor(.051,.067,.09,1):t.clearColor(1,1,1,1),t.clear(t.COLOR_BUFFER_BIT),t.enable(t.BLEND),t.blendFunc(t.SRC_ALPHA,t.ONE_MINUS_SRC_ALPHA);let P=[],L=-1,D=[];if($&&!o.current.manualPriceScale&&r&&r.length>0){let s=1/0,a=-1/0;const _=Math.max(0,Math.min(r.length-1,Math.floor(o.current.logicalRange.from))),A=Math.max(0,Math.min(r.length-1,Math.ceil(o.current.logicalRange.to)));for(let g=_;g<=A;g++){const i=r[g];i&&Number.isFinite(i.low)&&Number.isFinite(i.high)&&(i.low<s&&(s=i.low),i.high>a&&(a=i.high))}if(s===1/0||a===-1/0)for(let g=0;g<r.length;g++){const i=r[g];i&&Number.isFinite(i.low)&&Number.isFinite(i.high)&&(i.low<s&&(s=i.low),i.high>a&&(a=i.high))}if(s!==1/0&&a!==-1/0){let g=(a-s)*.1;g===0&&(g=a*.01||1);const i=s-g,f=a+g,d=i-o.current.priceRange.min,M=f-o.current.priceRange.max;(Math.abs(d)>1e-6||Math.abs(M)>1e-6)&&(o.current.priceRange.min+=d*.4,o.current.priceRange.max+=M*.4,requestAnimationFrame(rt))}}const b=o.current.logicalRange,ot=b.to-b.from||1,{min:E,max:U}=o.current.priceRange,it=U-E||1,I=o.current.hoverPixel,R=Math.max(4,Math.floor(v/(60*p))),O=it/R,V=Math.pow(10,Math.floor(Math.log10(O))),G=O/V;let q=1;G>7.5?q=10:G>3.5?q=5:G>1.5&&(q=2);const C=Math.max(1e-6,q*V),Z=C>=1?0:C>=.1||C>=.01?2:C>=.001?3:4,at=s=>{let a=0;const _=8;for(let A=0;A<s.length;A++){const g=Lt.current[s[A]];g&&(a+=g.w-_*2)}return a};let nt=36*p;const lt=Math.floor(E/C)*C;for(let s=lt;s<=U;s+=C){if(s<E||s>U)continue;const a=at(s.toFixed(Z));a>nt&&(nt=a)}const x=nt+16*p;o.current.pAxisW=x/p;const B=(e-x)/(ot*10),mt=-(b.from*10*B),vt=Math.max(0,Math.floor(b.from)),Rt=Math.min(r.length-1,Math.ceil(b.to)),It=[];let Tt=-1,_t=-1;for(let s=vt;s<=Rt;s++){if(!r[s])continue;const a=r[s].time,_=a<1e10?a*1e3:a,A=new Date(_),g=A.getUTCMonth(),i=A.getUTCDate(),f=A.getUTCHours(),d=A.getUTCMinutes(),M=g!==Tt&&Tt!==-1,n=i!==_t&&_t!==-1&&!M;Tt=g,_t=i;const l=M&&A.getUTCMonth()===0;let u=!1,m="";if(l)m=A.getUTCFullYear().toString(),u=!0;else if(M)m=A.toLocaleString("default",{month:"short",timeZone:"UTC"}),u=!0;else if(n)m=`${A.getUTCDate()} ${A.toLocaleString("default",{month:"short",timeZone:"UTC"})}`,u=!0;else{const T=Math.max(1,Math.floor((b.to-b.from||1)/12));if(s%T!==0)continue;m=`${f.toString().padStart(2,"0")}:${d.toString().padStart(2,"0")}`}const c=Math.max(1,10*B*.8),y=s*10*B+mt+c*.5;It.push({x:y,label:m,isMajor:u})}P=Qt({timeLabels:It,cW:e,pAxisW:x});const Bt=s=>{let a=0;const _=8;for(let A=0;A<s.length;A++){const g=Lt.current[s[A]];g&&g.h-_*2>a&&(a=g.h-_*2)}return a||12*p},ct=(P.length>0?Math.max(...P.map(s=>Bt(s.label))):12*p)+16*p;h=v-ct,o.current.timeAxisH=ct/p;const N=h/it,Vt=0,Nt=[];for(let s=lt;s<=U;s+=C){if(s<E||s>U)continue;const a=h-(s-E)*N;Nt.push({y:a,p:s,label:s.toFixed(Z)})}D=jt({priceLabels:Nt,cH:v,timeAxisH:ct});const ft=H.current.grid;if(ft){t.useProgram(ft),t.uniform2f(t.getUniformLocation(ft,"u_resolution"),e,v),t.uniform2f(t.getUniformLocation(ft,"u_axisSize"),x,ct),t.uniform1f(t.getUniformLocation(ft,"u_darkMode"),Y?1:0);let s=[.031,.6,.505,1];if(r&&r.length>0){const _=r[r.length-1];s=_.close>=_.open?[.031,.6,.505,1]:[.949,.211,.27,1],L=h-(_.close-E)*N}t.uniform1f(t.getUniformLocation(ft,"u_livePixelY"),L),t.uniform4fv(t.getUniformLocation(ft,"u_liveColor"),s);const a=t.getAttribLocation(ft,"a_position");t.enableVertexAttribArray(a),t.bindBuffer(t.ARRAY_BUFFER,S.current.fsQuad),t.vertexAttribPointer(a,2,t.FLOAT,!1,0,0),t.drawArrays(t.TRIANGLES,0,6),t.disableVertexAttribArray(a)}const pt=H.current.line;if(pt){t.useProgram(pt),t.uniform2f(t.getUniformLocation(pt,"u_resolution"),e,v);const s=[],a=[],_=(n,l,u,m,c)=>{s.push(n,l,c[0],c[1],c[2],c[3]),s.push(u,m,c[0],c[1],c[2],c[3])},A=(n,l,u,m,c)=>{const y=n-u/2,T=n+u/2,w=l,W=l+m;a.push(y,w,...c),a.push(T,w,...c),a.push(y,W,...c),a.push(y,W,...c),a.push(T,w,...c),a.push(T,W,...c)},g=Y?[.168,.184,.223,1]:[.878,.89,.921,1];if(P.forEach(({x:n})=>_(n,0,n,h,g)),D.forEach(({y:n})=>_(0,n,e-x,n,g)),_(e-x,0,e-x,h,g),_(0,h,e-x,h,g),r&&r.length>0){let n=0;for(let l=vt;l<=Rt;l++)r[l]?.volume>n&&(n=r[l].volume);if(n>0){const l=10*B,u=Math.max(1,l*.8);for(let m=vt;m<=Rt;m++){const c=r[m];if(!c)continue;const y=m*10*B+mt+u*.5,T=c.volume/n*(v*.15),W=c.close>=c.open?[16/255,185/255,129/255,.35]:[239/255,68/255,68/255,.35];A(y,h-T,u,T,W)}}}if(r&&r.length>1&&At&&At.length>0){const n=["#ff9800","#2962ff","#26a69a","#e040fb","#00e676","#ff5722","#00bcd4","#9c27b0"];At.forEach((l,u)=>{if(!l.visible)return;const m=Kt[l.type];if(!m||m.kind!=="overlay")return;const c=bt[l.id];c&&m.seriesConfig.forEach((y,T)=>{const w=c[y.key];if(!w||w.length<2)return;const W=l.color||n[(u+T)%n.length];let ut=.16,Ft=.5,Ut=.96,Ct=1;if(W&&W.startsWith("#")){const X=W.replace("#","");X.length===6&&(ut=parseInt(X.substring(0,2),16)/255,Ft=parseInt(X.substring(2,4),16)/255,Ut=parseInt(X.substring(4,6),16)/255)}for(let X=Math.max(1,vt);X<=Rt;X++){if(w[X-1]===void 0||w[X]===void 0)continue;const Gt=(X-1)*10*B+mt+Math.max(1,10*B*.8)*.5,qt=X*10*B+mt+Math.max(1,10*B*.8)*.5,kt=h-(w[X-1]-E)*N,$t=h-(w[X]-E)*N;_(Gt,kt,qt,$t,[ut,Ft,Ut,Ct])}})})}if(St&&St.length>0){const n=[.2,.6,1,1];St.forEach(l=>{if(l.tool==="trendline"&&l.points.length>=2){const u=w=>(Pt(w,r)-b.from)/(b.to-b.from)*(e-x),m=u(l.points[0].time),c=u(l.points[1].time),y=h-(l.points[0].price-E)*N,T=h-(l.points[1].price-E)*N;_(m,y,c,T,n)}})}if(gt==="trendline"&&K.current.activeDrawStart&&K.current.activeTempShape){const n=[.2,.6,1,1],l=T=>(Pt(T,r)-b.from)/(b.to-b.from)*(e-x),u=l(K.current.activeDrawStart.time),m=l(K.current.activeTempShape.time),c=h-(K.current.activeDrawStart.price-E)*N,y=h-(K.current.activeTempShape.price-E)*N;_(u,c,m,y,n)}if(I){const n=I.x*p,l=I.y*p,u=[1,1,1,.3];n>=0&&n<=e-x&&l>=0&&l<=h&&(_(n,0,n,h,u),_(0,l,e-x,l,u))}t.enable(t.SCISSOR_TEST),t.scissor(0,Math.floor(24*p),Math.floor(e-x),Math.floor(h));const i=t.getAttribLocation(pt,"a_position"),f=t.getAttribLocation(pt,"a_color");if(t.enableVertexAttribArray(i),t.enableVertexAttribArray(f),a.length>0){const n=new Float32Array(a);t.bindBuffer(t.ARRAY_BUFFER,S.current.dynamic),t.bufferData(t.ARRAY_BUFFER,n,t.DYNAMIC_DRAW),t.vertexAttribPointer(i,2,t.FLOAT,!1,24,0),t.vertexAttribPointer(f,4,t.FLOAT,!1,24,8),t.drawArrays(t.TRIANGLES,0,n.length/6)}if(s.length>0){const n=new Float32Array(s);t.bindBuffer(t.ARRAY_BUFFER,S.current.dynamic),t.bufferData(t.ARRAY_BUFFER,n,t.DYNAMIC_DRAW),t.vertexAttribPointer(i,2,t.FLOAT,!1,24,0),t.vertexAttribPointer(f,4,t.FLOAT,!1,24,8),t.drawArrays(t.LINES,0,n.length/6)}t.disableVertexAttribArray(i),t.disableVertexAttribArray(f),t.disable(t.SCISSOR_TEST);const d=[],M=(n,l,u,m,c)=>{d.push(n,l,...c),d.push(u,l,...c),d.push(n,m,...c),d.push(n,m,...c),d.push(u,l,...c),d.push(u,m,...c)};if(L>=0&&L<=h&&r&&r.length>0){const n=r[r.length-1],c=n.close>=n.open?[.031,.6,.505,1]:[.949,.211,.27,1];M(e-x,L-10*p,e,L+10*p,c)}if(I){const n=I.x*p,l=I.y*p,u=Y?[.165,.18,.224,1]:[.878,.89,.922,1];n>=0&&n<=e-x&&l>=0&&l<=h&&(M(e-x,l-11*p,e,l+11*p,u),M(n-60*p,h,n+60*p,h+ct,u))}if(d.length>0){const n=new Float32Array(d);t.bindBuffer(t.ARRAY_BUFFER,S.current.dynamic),t.bufferData(t.ARRAY_BUFFER,n,t.DYNAMIC_DRAW);const l=t.getAttribLocation(pt,"a_position"),u=t.getAttribLocation(pt,"a_color");t.enableVertexAttribArray(l),t.vertexAttribPointer(l,2,t.FLOAT,!1,24,0),t.enableVertexAttribArray(u),t.vertexAttribPointer(u,4,t.FLOAT,!1,24,8),t.drawArrays(t.TRIANGLES,0,n.length/6),t.disableVertexAttribArray(l),t.disableVertexAttribArray(u)}}const J=H.current.candle,wt=st?[...r,st]:r;if(J&&wt&&wt.length>0){t.useProgram(J),t.uniform2f(t.getUniformLocation(J,"u_resolution"),e,v),t.uniform2f(t.getUniformLocation(J,"u_scale"),B,N),t.uniform2f(t.getUniformLocation(J,"u_offset"),mt,Vt),t.uniform2f(t.getUniformLocation(J,"u_priceRange"),E,U);const s=wt.length,a=new Float32Array(s*4),_=new Float32Array(s*2);for(let f=0;f<s;f++){const d=wt[f];a[f*4]=d.open,a[f*4+1]=d.high,a[f*4+2]=d.low,a[f*4+3]=d.close,_[f*2]=f,_[f*2+1]=d.isPrediction?1:0}t.bindBuffer(t.ARRAY_BUFFER,S.current.candlePrices),t.bufferData(t.ARRAY_BUFFER,a,t.DYNAMIC_DRAW),t.bindBuffer(t.ARRAY_BUFFER,S.current.candleMeta),t.bufferData(t.ARRAY_BUFFER,_,t.DYNAMIC_DRAW);const A=t.getAttribLocation(J,"a_position");t.enableVertexAttribArray(A),t.bindBuffer(t.ARRAY_BUFFER,S.current.quad),t.vertexAttribPointer(A,2,t.FLOAT,!1,0,0);const g=t.getAttribLocation(J,"a_candlePrices");t.enableVertexAttribArray(g),t.bindBuffer(t.ARRAY_BUFFER,S.current.candlePrices),t.vertexAttribPointer(g,4,t.FLOAT,!1,0,0),t.vertexAttribDivisor(g,1);const i=t.getAttribLocation(J,"a_candleMeta");t.enableVertexAttribArray(i),t.bindBuffer(t.ARRAY_BUFFER,S.current.candleMeta),t.vertexAttribPointer(i,2,t.FLOAT,!1,0,0),t.vertexAttribDivisor(i,1),t.enable(t.SCISSOR_TEST),t.scissor(0,Math.floor(24*p),Math.floor(e-x),Math.floor(h)),t.uniform1f(t.getUniformLocation(J,"u_isWick"),0),t.drawArraysInstanced(t.TRIANGLES,0,6,s),t.uniform1f(t.getUniformLocation(J,"u_isWick"),1),t.drawArraysInstanced(t.TRIANGLES,0,6,s),t.vertexAttribDivisor(g,0),t.vertexAttribDivisor(i,0),t.disableVertexAttribArray(A),t.disableVertexAttribArray(g),t.disableVertexAttribArray(i),t.disable(t.SCISSOR_TEST)}const xt=H.current.sdfText,zt=Lt.current;if(xt&&Et.current&&(P.length>0||D.length>0)){t.useProgram(xt),t.activeTexture(t.TEXTURE0),t.bindTexture(t.TEXTURE_2D,Et.current),t.uniform1i(t.getUniformLocation(xt,"u_fontTexture"),0),t.uniform2f(t.getUniformLocation(xt,"u_resolution"),e,v);const s=Y?[.788,.82,.851,1]:[.075,.09,.133,1];t.uniform4fv(t.getUniformLocation(xt,"u_textColor"),s);const a=[],_=(i,f,d,M,n)=>{const u=n.x/512,m=n.y/512,c=(n.x+n.cellW)/512,y=(n.y+n.cellH)/512,T=i,w=i+d,W=f,ut=f+M;a.push(T,W,u,m),a.push(w,W,c,m),a.push(T,ut,u,y),a.push(T,ut,u,y),a.push(w,W,c,m),a.push(w,ut,c,y)},A=(i,f,d)=>{let M=Math.round(f);const n=Math.round(d),l=8;for(let u=0;u<i.length;u++){const m=i[u],c=zt[m];if(!c)continue;const y=c.w-l*2;_(M-l,n-c.cellH/2,c.cellW,c.cellH,c),M+=y}},g=i=>{let f=0;const d=8;for(let M=0;M<i.length;M++){const n=zt[i[M]];n&&(f+=n.w-d*2)}return f};if(P.forEach(({x:i,label:f})=>{const d=g(f);A(f,Math.floor(i-d/2),Math.floor(h+ct/2))}),D.forEach(({y:i,label:f})=>{const d=g(f),M=Math.floor(e-x+(x-d)/2);A(f,M,i)}),r&&r.length>0){const i=r[r.length-1];if(L>=0&&L<=h){const f=i.close.toFixed(Z),d=g(f),M=Math.floor(e-x+(x-d)/2);A(f,M,Math.floor(L))}}if(I){const i=I.x*p,f=I.y*p;if(i>=0&&i<=e-x&&f>=0&&f<=h){const M=(U-f/N).toFixed(Z),n=g(M),l=Math.round(e-x+(x-n)/2);A(M,l,Math.round(f));const u=b.from+i/(e-x)*ot,m=Math.min(r.length-1,Math.max(0,Math.floor(u))),c=r[m];if(c){const y=c.time<1e10?c.time*1e3:c.time,T=new Date(y),w=T.getDate().toString().padStart(2,"0"),W=T.toLocaleString("en-US",{month:"short"}),ut=T.getFullYear().toString().slice(-2),Ft=T.getHours().toString().padStart(2,"0"),Ut=T.getMinutes().toString().padStart(2,"0"),Ct=`${w} ${W} '${ut} ${Ft}:${Ut}`,X=g(Ct);A(Ct,Math.floor(i-X/2),Math.floor(h+ct/2))}}}if(a.length>0){t.bindBuffer(t.ARRAY_BUFFER,S.current.text),t.bufferData(t.ARRAY_BUFFER,new Float32Array(a),t.DYNAMIC_DRAW);const i=t.getAttribLocation(xt,"a_position"),f=t.getAttribLocation(xt,"a_uv");t.enableVertexAttribArray(i),t.vertexAttribPointer(i,2,t.FLOAT,!1,16,0),t.enableVertexAttribArray(f),t.vertexAttribPointer(f,2,t.FLOAT,!1,16,8),t.drawArrays(t.TRIANGLES,0,a.length/4),t.disableVertexAttribArray(i),t.disableVertexAttribArray(f)}}Q&&Q()};return F.useEffect(()=>{const t=dt.current;if(!t)return;let e=!1,v=0,h=0,P=0,L=0,D=0,b=0;const ot=R=>{const{left:O,top:V}=t.getBoundingClientRect(),G=R.clientX-O,q=R.clientY-V,C=o.current.width,Z=o.current.height,at=o.current.pAxisW||65;G>C-at||q>Z-(o.current.timeAxisH||28)||(e=!0,v=R.clientX,h=R.clientY,P=o.current.logicalRange.from,L=o.current.logicalRange.to,D=o.current.priceRange.min,b=o.current.priceRange.max,t.setPointerCapture(R.pointerId))},E=R=>{const{left:O,top:V}=t.getBoundingClientRect(),G=R.clientX-O,q=R.clientY-V,C=o.current.width,Z=o.current.height,{min:at,max:nt}=o.current.priceRange,lt=nt-at;lt>0&&(Z-(o.current.timeAxisH||28))/lt;const x=o.current.logicalRange,B=x.to-x.from,mt=o.current.pAxisW||65,vt=x.from+G/(C-mt)*B,Rt=Math.min(r.length-1,Math.max(0,Math.floor(vt)));if(r[Rt]?.time,o.current.hoverPixel={x:G,y:q},!e)return;const Tt=R.clientX-v,_t=R.clientY-h,Bt=B/C,Wt=Tt*Bt;if(o.current.logicalRange.from=P-Wt,o.current.logicalRange.to=L-Wt,Math.abs(_t)>2&&(o.current.manualPriceScale=!0),o.current.manualPriceScale){const ct=(Z-26)/(b-D||1),N=_t/ct;o.current.priceRange.min=D+N,o.current.priceRange.max=b+N}et&&r&&r.length>0&&et({from:r[Math.max(0,Math.floor(o.current.logicalRange.from))]?.time,to:r[Math.min(r.length-1,Math.ceil(o.current.logicalRange.to))]?.time}),requestAnimationFrame(rt)},U=R=>{e=!1,t.releasePointerCapture(R.pointerId)},it=R=>{R.preventDefault();const O=t.getBoundingClientRect(),V=o.current.width,G=o.current.logicalRange.to-o.current.logicalRange.from;if(Math.abs(R.deltaX)>Math.abs(R.deltaY)){const q=G/V,C=R.deltaX*.5*q;o.current.logicalRange.from+=C,o.current.logicalRange.to+=C}else{const q=Math.max(0,Math.min(V,R.clientX-O.left)),C=o.current.pAxisW||65,Z=Math.max(1,V-C),at=Math.max(0,Math.min(1,q/Z));let nt;R.ctrlKey?nt=Math.exp(R.deltaY*.015):nt=Math.exp(R.deltaY*.0018);const lt=o.current.logicalRange.from+G*at,x=Math.max(5,Math.min(5e4,G*nt));o.current.logicalRange.from=lt-x*at,o.current.logicalRange.to=lt+x*(1-at)}et&&r&&r.length>0&&et({from:r[Math.max(0,Math.floor(o.current.logicalRange.from))]?.time,to:r[Math.min(r.length-1,Math.ceil(o.current.logicalRange.to))]?.time}),requestAnimationFrame(rt)},I=()=>{e=!1,o.current.hoverPixel=null,requestAnimationFrame(rt)};return t.addEventListener("pointerdown",ot),t.addEventListener("pointermove",E),t.addEventListener("pointerup",U),t.addEventListener("pointercancel",U),t.addEventListener("pointerleave",I),t.addEventListener("wheel",it,{passive:!1}),()=>{t.removeEventListener("pointerdown",ot),t.removeEventListener("pointermove",E),t.removeEventListener("pointerup",U),t.removeEventListener("pointercancel",U),t.removeEventListener("pointerleave",I),t.removeEventListener("wheel",it)}},[r,et]),F.useImperativeHandle(Mt,()=>({render:()=>requestAnimationFrame(rt),scrollToRealTime:()=>{if(!r||r.length===0)return;const t=r.length-1,e=o.current.logicalRange.to-o.current.logicalRange.from||100,v=e*.2;o.current.logicalRange.from=t-e+v,o.current.logicalRange.to=t+v,o.current.manualPriceScale=!1,requestAnimationFrame(rt),et&&et({from:r[Math.max(0,Math.floor(o.current.logicalRange.from))]?.time,to:r[Math.min(r.length-1,Math.ceil(o.current.logicalRange.to))]?.time})},timeScale:()=>({getVisibleLogicalRange:()=>o.current.logicalRange,getVisibleRange:()=>null,fitContent:()=>{}}),priceScale:()=>({applyOptions:()=>{}}),captureViewport:()=>({logicalRange:o.current.logicalRange}),applyViewport:t=>{t&&t.logicalRange&&(o.current.logicalRange=t.logicalRange)},getPixel:(t,e)=>{const v=o.current.width*p,h=o.current.height*p,P=(o.current.pAxisW||65)*p,L=h-(o.current.timeAxisH||28)*p,{min:D,max:b}=o.current.priceRange,ot=b-D,E=ot>0?L/ot:1,U=o.current.logicalRange,it=U.to-U.from,R=(Pt(t,r)-U.from)/it*(v-P),O=L-(e-D)*E;return{x:R/p,y:O/p}},coordinateToTimePrice:(t,e)=>{if(!r||r.length===0)return null;const v=o.current.width,h=o.current.height,P=o.current.pAxisW||65,L=h-(o.current.timeAxisH||28),D=v-P,b=o.current.logicalRange,ot=b.to-b.from,E=Math.round(b.from+t/D*ot),U=Math.max(0,Math.min(r.length-1,E)),it=r[U]?.time||0,{min:I,max:R}=o.current.priceRange,O=R-I,V=R-e/(L/O);return{time:it,price:V}}})),F.useEffect(()=>{requestAnimationFrame(rt)},[r,St,At,bt,Y]),Ht.jsx("div",{ref:dt,className:`w-full h-full relative ${Y?"bg-[#131722]":"bg-[#ffffff]"} overflow-hidden cursor-crosshair`,children:Ht.jsx("canvas",{ref:j,className:"absolute top-0 left-0 w-full h-full touch-none"})})});export{pe as default};
